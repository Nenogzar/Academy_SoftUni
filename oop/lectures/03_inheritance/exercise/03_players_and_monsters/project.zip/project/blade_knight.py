from project.dark_knight import DarkKnight

class BladeKnight(DarkKnight):
    pass