from project.equipment.elbow_pad import ElbowPad
from project.equipment.knee_pad import KneePad
from project.teams.indoor_team import IndoorTeam

eqk = KneePad()
print(eqk.price, "price")
eqk.increase_price()
print(eqk.price, "increases price")
print(eqk.protection, "protection")
print("-------")
eqe = ElbowPad()
print(eqe.price, "price")
eqe.increase_price()
print(eqe.price, "increases price")
print(eqe.protection, "protection")


print("-------")

try:
    ti = IndoorTeam("Peshtera", "BG", 15)
except ValueError as t:
    print(t)
