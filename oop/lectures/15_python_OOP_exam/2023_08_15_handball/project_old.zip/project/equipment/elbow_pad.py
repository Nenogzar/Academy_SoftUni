from project.equipment.base_equipment import BaseEquipment

class ElbowPad(BaseEquipment):
    def __init__(self):
        super().__init__()