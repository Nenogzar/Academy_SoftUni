from abc import ABC, abstractmethod


class BaseEquipment(ABC):
    equipment_properties = {
        'ElbowPad': {'PROTECTION': 90, 'PRICE': 25.0, 'INCREASES_PRICE': 1.1},
        'KneePad': {'PROTECTION': 120, 'PRICE': 15.0, 'INCREASES_PRICE': 1.2}
    }

    def __init__(self, protection: int = None, price: float = None):
        self.protection = protection
        self.price = price
        self.class_name = self.__class__.__name__

        #
        # self._protection = self.equipment_properties[class_name]['PROTECTION']
        # self._price = self.equipment_properties[class_name]['PRICE']

    @property
    def protection(self):
        return self._protection

    @protection.setter
    def protection(self):
        self._protection = self.equipment_properties[self.class_name]['PROTECTION']

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self):
        self._price = self.equipment_properties[self.class_name]['PRICE']

    def increase_price(self) -> None:
        class_name = self.__class__.__name__
        increase_factor = self.equipment_properties[class_name]['INCREASES_PRICE']
        self._price *= increase_factor
